<html lang="en">

<head>
    <?php
    include 'page_parts/page_head.php';
    ?>
    <link rel="stylesheet" href="styles/index.css">
    <title>Cinema</title>
</head>

<body>
    <div class="home">
        <?php include 'page_parts/header.php'; ?>
        <div class="image">
        </div>
    </div>
    <?php include 'page_parts/footer.php'; ?>
</body>

</html>