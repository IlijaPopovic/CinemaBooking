<html lang="en">

<head>
    <?php
    include 'page_parts/page_head.php';
    ?>
    <link rel="stylesheet" href="styles/soon.css">
    <title>Cinema</title>
</head>

<body>
    <?php include 'page_parts/header.php'; ?>
    <div class="container">
        <h2>Soon</h2>
    </div>
    <div class="main">
    </div>

    <?php include 'page_parts/footer.php'; ?>

    <script src="scripts/soon.js"></script>
</body>

</html>