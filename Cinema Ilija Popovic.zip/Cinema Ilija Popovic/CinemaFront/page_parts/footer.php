<!-- <footer class="footer animate__animated animate__zoomInDown"> -->
<footer class="footer">
    <div class="container">
        <div class="up_footer">
            <p>Follow us:</p>
            <div class="social_footer">
                <a href=""><i class="fab fa-facebook-f"></i></a>
                <a href=""><i class="fab fa-twitter"></i></a>
                <a href=""><i class="fab fa-youtube"></i></a>
                <a href=""><i class="fab fa-instagram"></i></a>
                <a href=""><i class="fab fa-linkedin-in"></i></a>
            </div>
        </div>
        <div class="down_footer">
            <p>All Rights Reserved Ilija Popovic <?php echo date("d/m/Y"); ?> &copy;</p>
        </div>
    </div>
</footer>